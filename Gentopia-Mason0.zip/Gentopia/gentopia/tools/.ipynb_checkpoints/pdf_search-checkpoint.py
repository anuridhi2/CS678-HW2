#!pip install pypdf
from pypdf import PdfReader
from typing import AnyStr
from googlesearch import search
from gentopia.tools.basetool import *
import requests
import io

class PdfSearchArgs(BaseModel):
    pdfurl: str = Field(..., description="the url of the pdf to read")
    #query: str = Field(..., description="a search query")


class PdfSearch(BaseTool):
    """Tool that adds the capability to read the pdfs from input url."""

    name = "pdf_search"
    description = ("A pdf reader that retreives the information in the pdf."
                   "Input should be a pdf url.")

    args_schema: Optional[Type[BaseModel]] = PdfSearchArgs

    def _run(self, pdfurl: AnyStr) -> str:
        answer = requests.get(pdfurl)
        pdf = io.BytesIO(answer.content)
        reader = PdfReader(pdf)
        x = len(reader.pages)
        
        page = [reader.pages[i] for i in range(x)]
        
        return '\n\n'.join([x.extract_text() for x in page])
        
        #return '\n\n'.join([str(item) for item in search(query, advanced=True)])

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


if __name__ == "__main__":
    ans = PdfSearch()._run("https://arxiv.org/pdf/2407.02067")
    print(ans)
