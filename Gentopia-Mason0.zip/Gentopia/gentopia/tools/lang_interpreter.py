#pip install langdetect
#pip install googletrans
from langdetect import detect
from googletrans import Translator
from typing import AnyStr
from googlesearch import search
from gentopia.tools.basetool import *
import requests
import io

class LangInterpretArgs(BaseModel):
    query: str = Field(..., description="a search query in a different language")


class LangInterpret(BaseTool):
    """Tool that adds the capability to read the language and tell the language name"""

    name = "lang_interpreter"
    description = ("A langauge reader that interprets the langauge and translates"
                   "Input should be a pdf url.")

    args_schema: Optional[Type[BaseModel]] = LangInterpretArgs

    def _run(self, query: AnyStr) -> str:

        return translator.translate(query)
    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


if __name__ == "__main__":
    ans = LangInterpret()._run("War doesn't show who's right, just who's left.")
    print(ans)
